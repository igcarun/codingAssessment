import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-BGPACWNO.js";
import "./chunk-ASFTHJZN.js";
import "./chunk-65BEA5NI.js";
import "./chunk-B3GSJQ5F.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
//# sourceMappingURL=@angular_cdk_text-field.js.map
