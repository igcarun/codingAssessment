import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatRadioModule} from '@angular/material/radio';
import {MatSelectModule} from '@angular/material/select';
import { JsonPipe } from '@angular/common';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

// Row Data Interface
interface IRow {
  id: string;
  name: string;
  gender: string;
  designation: string;
  about: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, FormsModule, ReactiveFormsModule,
    MatFormFieldModule, MatInputModule, FormsModule, MatButtonModule, MatIconModule, 
    MatRadioModule, MatSelectModule, JsonPipe, AgGridAngular],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {

  title = 'clientTest';
  genderOptions = ['Male', 'Female', 'Transgender'];
  designationOptions = [{value: 'clerk', dest: 'Clerk'},
  {value: 'Manager', dest: 'Manager'},
  {value: 'Accountant', dest: 'Accountant'},
  {value: 'HR', dest: 'HR'},
  {value: 'Insurance', dest: 'Insurance'}]

  employeeFormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    gender: new FormControl('', Validators.required),
    designation: new FormControl('', Validators.required),
    about: new FormControl('', Validators.required),
    address: new FormGroup({
      city: new FormControl('', Validators.required),
      country: new FormControl('', Validators.required),
    })
  })

  employeeList!: IRow[];

  colDefs: ColDef<IRow>[] = [
    { field: 'id' },
    { field: 'name' },
    { field: 'gender' },
    { field: 'designation' },
    { field: 'about'}
  ];

  ngOnInit(): void {
    const employeeDatas = localStorage.getItem('employeeList');
    console.log('empoleee', employeeDatas);
    if (employeeDatas) {
       this.employeeList = JSON.parse(employeeDatas);
       console.log(this.employeeList);
    }
  }

  saveEmployee() {
    const data = {
      id: 1,
      name: this.employeeFormGroup.get('name')?.value,
      gender: this.employeeFormGroup.get('gender')?.value,
      designation: this.employeeFormGroup.get('designation')?.value,
      about: this.employeeFormGroup.get('about')?.value,
      address: {
        city: this.employeeFormGroup.get('address')?.get('city')?.value,
        country: this.employeeFormGroup.get('address')?.get('country')?.value
      }
    };
    const employeeDatas = localStorage.getItem('employeeList');
    if (employeeDatas) {
      const employeeList = JSON.parse(employeeDatas);
      console.log(employeeList);
      data.id = employeeList.length+1;
      employeeList.push(data);
      localStorage.setItem('employeeList', JSON.stringify(employeeList));
      this.employeeList = employeeList;
    } else {
      data.id = 1;
      localStorage.setItem('employeeList', JSON.stringify([data]));
    }

    this.employeeFormGroup.reset();
  }
}
